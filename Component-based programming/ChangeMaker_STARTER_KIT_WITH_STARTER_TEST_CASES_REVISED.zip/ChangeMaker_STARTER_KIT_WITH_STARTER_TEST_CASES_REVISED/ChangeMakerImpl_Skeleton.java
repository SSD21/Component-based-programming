package change;

import java.util.List;
import java.util.Set;

public class ChangeMakerImpl_Skeleton implements ChangeMaker
{	
	//part of pre: i <= 0 ==> !denominations.contains(i)
	//Student should figure out other parts of the precondition
	public ChangeMakerImpl_Skeleton(Set<Integer> denominations)
	{
		throw new RuntimeException("NOT IMPLEMENTED YET!");
	}
	
	public List<Integer> getDenominations()
	{
		throw new RuntimeException("NOT IMPLEMENTED YET!");
	}
	
	public boolean canMakeExactChange(int valueInCents)
	{
		throw new RuntimeException("NOT IMPLEMENTED YET!");
	}
	
	public int calculateValueOfChangeList(List<Integer> changeList)
	{
		throw new RuntimeException("NOT IMPLEMENTED YET!");
	}

	public List<Integer> getExactChange(int valueInCents)
	{
		throw new RuntimeException("NOT IMPLEMENTED YET!");
	}
	
	public String toString()
	{
		throw new RuntimeException("NOT IMPLEMENTED YET!");
	}
}
